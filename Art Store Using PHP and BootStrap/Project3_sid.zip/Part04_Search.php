<?php
$servername = "localhost";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$servername;dbname=art", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connected successfully";
}
catch(PDOException $e)
{
    //echo "Connection failed: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title></title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" />

    <!-- Custom CSS -->
    <link href="custom.css" rel="stylesheet" />
</head>
<?php include 'navigation.php'; ?>
<body>
    <div class="container">
        
        <h2>Search results</h2>
        <hr />
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="radio">
                    <label>
                        <input type="radio" id="chkFilterByTitle" />Filter By Title
                    </label>
                    <div id="title" class="form-group" style="display: none">
                        <input type="text" class="form-control" id="titleSearch" />
                    </div>
                </div>
                <div class="radio">
                    <label>
                        <input type="radio" id="chkFilterByDescription" />Filter By Description
                    </label>
                    <div id="description" class="form-group" style="display: none">
                        <input type="text" class="form-control" id="descriptionSearch" />
                    </div>
                </div>

                <div class="radio">
                    <label>
                        <input type="radio" name="optradio" id="none" />No filter (show all art works)
                    </label>
                </div>
                <button type="button" class="btn btn-primary" onclick="filter()">Filter</button>
            </div>

        </div>
        <div class="panel panel-default">
            <div class="panel-body">
                <?php
                $username="root";$password="";$database="art";
                mysql_connect("localhost",$username,$password);
                @mysql_select_db($database) or die( "Unable to select database");
                $query = 'SELECT * FROM artworks';
                if (isset($_GET['title'])) {
                    $query="SELECT * FROM artworks where Title LIKE  '%".$_GET['title']."%'";
                }
                if (isset($_GET['description'])) {
                    $query="SELECT * FROM artworks where Description LIKE  '%".$_GET['description']."%'";
                }

                $result=mysql_query($query);
                $file_path = 'images/art/works/square-medium/';
                $num=mysql_numrows($result);
                if($num > 0)
                {
                    while ($row = mysql_fetch_assoc($result))
                    {
                        $src=$file_path.$row['ImageFileName'].'.jpg';
                        echo "<div class='row' style='padding-top:15px'>";

                        echo "<div class='col-md-2'>";
                        echo "<img class='img-responsive' src='{$src}'>";
                        echo "</div>";
                        $path = "/Sid/Part03_SingleWork.php?id=".$row['ArtistID'];
                        echo "<div class='col-md-10'>";
                        echo "<a href='{$path}'><h4>{$row['Title']}</h4></a>";
                        if($row['Description'] == '')
                        {
                            echo "---No description---";
                        }
                        else
                        {
                            echo highlightkeyword($desc);
                        }
                        echo "</div>";
                        echo "</div>";

                        function highlightkeyword($str, $search) {
                            $highlightcolor = "#daa732";
                            $occurrences = substr_count(strtolower($str), strtolower($search));
                            $newstring = $str;
                            $match = array();

                            for ($i=0;$i<$occurrences;$i++) {
                                $match[$i] = stripos($str, $search, $i);
                                $match[$i] = substr($str, $match[$i], strlen($search));
                                $newstring = str_replace($match[$i], '[#]'.$match[$i].'[@]', strip_tags($newstring));
                            }

                            $newstring = str_replace('[#]', '<span style="color: '.$highlightcolor.';">', $newstring);
                            $newstring = str_replace('[@]', '</span>', $newstring);
                            return $newstring;

                        }
                    }
                }
                else{
                    //echo "No results";
                }
                ?>
            </div>
        </div>
    </div>
    <!-- jQuery -->
    <script src="bootstrap/js/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            var isTitle = false;
            var isDescription = false;
            $("#chkFilterByTitle").click(function () {
                $("#title").show();
                $("#description").hide();
                $(chkFilterByDescription).prop('checked', false);
                $(chkFilterByTitle).prop('checked', false);
                document.getElementById('descriptionSearch').value = "";
            });

            $("#chkFilterByDescription").click(function () {
                $("#description").show();
                $("#title").hide();
                $(chkFilterByTitle).prop('checked', false);
                $(none).prop('checked', false);
                document.getElementById('titleSearch').value = "";
            });

            $("#none").click(function () {
                $("#description").hide();
                $("#title").hide();
                $(chkFilterByTitle).prop('checked', false);
                $(chkFilterByDescription).prop('checked', false);
                isTitle = false;
                isDescription = false;
                document.getElementById('descriptionSearch').value = "";
                document.getElementById('titleSearch').value = "";
            });
        });

        function filter() {
            var searchPageBaseURL = '/sid/Part04_Search.php';
            var searchCriteria = '';
            if ($("#titleSearch").val() != "") {
                searchCriteria = "?title=" + $("#titleSearch").val();
            }
            else if ($("#descriptionSearch").val() != "") {
                searchCriteria = "?description=" + $("#descriptionSearch").val();
            }
            window.location = "http://" + window.location.hostname + ':' + window.location.port + searchPageBaseURL + searchCriteria;
        }
    </script>
</body>
</html>